import praw
import re
#from search import searchLayers

reddit = praw.Reddit('script1', user_agent='http://127.0.0.0')

subreddit = reddit.subreddit('tarkovtrading')
#subreddit = reddit.subreddit('testingground4bots')

SUB_FILENAME = "subscriptions.txt"
MESSAGES_FILENAME = "messages.txt"
REPLIED_TO_FILENAME = "replied.txt"

##def ContainsCommand(comment):
##    if trigger in comment:
##        return True
##    else:
##        return False
    
##def check(string):
##    string = string.replace(trigger + " ", "")
##    print(string)
##    if re.match(r'"[\w -]*" "[\w -]*"', string):
##        print("Both have quotes")
##        newString = string.split("\" \"")
##        i=0
##        for string in newString:
##            newString[i] = string.replace("\"", "")
##            i+=1
##        return newString
##    elif re.match(r'[\w-]* "[\w ()-]*"', string):
##        print("Only second has quotes")
##        newString = string.split(" \"")
##        i=0
##        for string in newString:
##            newString[i] = string.replace("\"", "")
##            i+=1
##        return newString
##    elif re.match(r'"[\w -]*" \w*', string):
##        print("Only first has quotes")
##        newString = string.split("\" ")
##        i=0
##        for string in newString:
##            newString[i] = string.replace("\"", "")
##            i+=1
##        return newString
##    elif re.match(r'[\w-]* \w*', string):
##        print("Neither have quotes")
##        newString = string.split(" ")
##        i=0
##        for string in newString:
##            newString[i] = string.replace("\"", "")
##            i+=1
##        return newString
##    elif re.match(r'"[\w -]*"', string):
##        print("Single command with quotes")
##        newString = string.split("\" \"")
##        i=0
##        for string in newString:
##            newString[i] = string.replace("\"", "")
##            i+=1
##        return newString
##    elif re.match(r'[\w-]', string):
##        print("Single word")
##        newString = string.split("\" \"")
##        i=0
##        for string in newString:
##            newString[i] = string.replace("\"", "")
##            i+=1
##        return newString
##    else:
##        return False


##def GenerateResponse(comment):
##    commands = [];
##    splitComment = comment.split("\n")
##    #print(splitComment)
##    for line in splitComment:
##        #print(line)
##        if line.startswith(trigger):
##            commands.append(line)
##    for command in commands:
##        response = check(command)
##        if response:
##            return response
##    #return "The comment meets the criteria"
##    return False

def NotYetRepliedTo(id):
    file = open(REPLIED_TO_FILENAME, "r")
    for line in file:
        if id in line:
            return False
    file = open(REPLIED_TO_FILENAME, "a")
    file.write(id+"\n")
    return True

def AddMessage(user,title,url):
    #print("_"*30)
    print("Sending message to "+user+" ("+title+")")
    file = open(MESSAGES_FILENAME, "a")
    file.write(user+"\t"+title+"\t"+url+"\n")
    file.close()

for comment in subreddit.stream.submissions():
    try:
        #print(10*'_' + str(comment.author) + 10*'_' + str(comment.permalink) + 10*'_')
        #print(comment.body)
        #print(3*'\n')
        #print("--"+comment.id+"--")
        if NotYetRepliedTo(comment.id):
            usersNotified = []
            sfiletemp = open(SUB_FILENAME,"r")
            sfile = []
            for sline in sfiletemp:
                sfile.append(sline)
            sfiletemp.close()
            for sline in sfile:
                #print("sline: "+sline)
                meetsTerms = True
                terms = sline.split("\t")[0].split(",")
                print("*"*45)
                print(comment.title)
                print(str(terms))
                for term in terms:
                    if not meetsTerms:
                        continue
                    #print("term: "+term)
                    #print("+"*40)
                    #print(str(term)+": "+str(rline).replace("\n", ""))
                    if term.lower() in comment.title.lower():
                        meetsTerms = True
                        #print("MeetsTerms")
                    else:
                        meetsTerms = False
                        #print("!MeetsTerms")
                    #print(usersNotified)
                #print("Does it meet terms: "+str(meetsTerms))      
                if meetsTerms:
                    #the line met all terms
                    users = sline.split("\t")[1].replace("\n", "")[2:len(sline.split("\t")[1].replace("\n", ""))-3].split("</><>")
                    for user in users:
                        if user not in usersNotified:
                            #print(str(user)+" in? "+str(usersNotified))
                            usersNotified.append(user)
                            #print(str(user)+": "+rline.split("\t")[1])
                            AddMessage(user,comment.title,comment.url)
    except praw.exceptions.PRAWException as e:
        pass


