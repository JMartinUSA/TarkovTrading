import discord
from discord.ext.commands import Bot
from discord.ext import commands
import praw
import asyncio
import re
import time

# SET CONSTS
BOT_PREFIX = ("?", "!")
TOKEN = ""
TRIGGERS = ["?tradealert","?tradebot","?tbot"]
SUB_FILENAME = "subscriptions.txt"
REDDIT_FILENAME = "reddit.txt"
MESSAGES_FILENAME = "messages.txt"
DOT = "•"

# SET VARS
messages = []
#messages.append(str(282182568101806080)+"\tWTB Keys\thttps://reddit.com/r/tarkovtrading/wtb_keys/")
print("messages assigned")

greeting = """Greetings human, I am DiscordTradeAlert. I am a  bot designed to help you trade on the r/TarkovTrading subreddit. 

You can use me by sending the ?tradealert, ?tradebot, or ?tbot command to any discord channel that I am a member of, or by sending the command as a direct message.

To be alerted whenever a post whose title includes the terms, MP5 && Drum && Mag, is submitted to r/TarkovTrading type:
```?tbot subscribe [term] MP5 Drum Mag```
To unsubscribe from the above alert type: (note that capitalization and the order of terms do not matter)
```?tbot unsubscribe dRuM MAg mP5```
If you would like a list of the alerts that you are currently subscribed to type:
```?tbot list```"""

# CREATE BOT
client = Bot(command_prefix=BOT_PREFIX)

# MY FUNCTIONS
def AddSubscription(userID, terms):
    print("Adding subscription")
    found = False
    output = "none"
    file = open(SUB_FILENAME, "r")
    lines = []
    for i, line in enumerate(file):
        lineTerms = line.split("\t")[0]
        lineUsers = line.split("\t")[1]
        if lineTerms == ",".join(terms):
            if userID in lineUsers:
            #if False:
                output = "You are already subscribed to this alert!"
            else:
                line = line.replace("\n","") + "<>"+userID+"</>\n"
                output = "You will be alerted when a trade including the following terms is posted:```"+DOT+", ".join(terms)+"```"
            print(line)
            lines.append(line)
            found = True
        else:
            lines.append(line)
    if not found:
        lines.append(",".join(terms)+"\t<>"+userID+"</>\n")
        output = "You will be alerted when a trade including the following terms is posted:```"+" ".join(terms)+"```"
    file.close()
    print("Done looping")
    file = open(SUB_FILENAME, "w")
    print(str(lines))
    file.writelines(lines)
    file.close()
    return output
    
def RemoveSubscription(userID, terms):
    print("Removing subscription")
    found = False
    output = "none"
    file = open(SUB_FILENAME, "r")
    lines = []
    for i, line in enumerate(file):
        lineTerms = line.split("\t")[0]
        lineUsers = line.split("\t")[1]
        if lineTerms == ",".join(terms):
            print("Matched terms")
            if userID in lineUsers:
                found = True
                print("Has user")
                #remove user from line if there are others, otherwise remove complete line
                if "</><>" in lineUsers:
                    print("Has multiple")
                    #there are multiple users
                    print(lineUsers)
                    lineUsers = lineUsers.replace("<>"+userID+"</>", "")
                    print(lineUsers)
                    lines.append(lineTerms+"\t"+lineUsers)
                    output = "You are no longer subscribed to this alert."
                else:
                    print("Single user")
                    output = "You are no longer subscribed to this alert."
            else:
                #user not subscribed
                output = "You were not subscribed to this alert."
        else:
            #terms didn't match
            lines.append(line)
    if not found:
        output = "You were not subscribed to this alert."
    file.close()
    print("Done looping")
    file = open(SUB_FILENAME, "w")
    print(str(lines))
    file.writelines(lines)
    file.close()    
    return output

def ListSubscriptions(userID):
    found = False
    output = "none"
    file = open(SUB_FILENAME, "r")
    for i, line in enumerate(file):
        lineTerms = line.split("\t")[0]
        lineUsers = line.split("\t")[1]
        if "<>"+userID+"</>" in lineUsers:
            #user is subscribed
            print(output)
            if not found:
                #this is the first match
                found = True
                output = "You are subscribed to the following alerts:```"
                output += DOT+" "+lineTerms.replace(",", ", ")
            else:
                output += "\n"+DOT+" "+lineTerms.replace(",", ", ")
    if not found:
        output = "You are not subscribed to any alerts"
    else:
        output += "```"
    return output

def CheckForNew():
    print("-#-"*10)
    rfiletemp = open(REDDIT_FILENAME,"r")
    rfile = []
    for rline in rfiletemp:
        rfile.append(rline)
    rfiletemp.close()
    rfiletemp = open(REDDIT_FILENAME,"w")
    rfiletemp.close()
    sfiletemp = open(SUB_FILENAME,"r")
    sfile = []
    for sline in sfiletemp:
        sfile.append(sline)
    rfiletemp.close()
    sfiletemp.close()
    #print(len(rfile))
    for rline in rfile:
        #print("rline: "+rline)
        usersNotified = []
        for sline in sfile:
            #print("sline: "+sline)
            meetsTerms = True
            terms = sline.split("\t")[0].split(",")
            for term in terms:
                if not meetsTerms:
                    continue
                #print("term: "+term)
                #print("+"*40)
                #print(str(term)+": "+str(rline).replace("\n", ""))
                if term in rline:
                    meetsTerms = True
                    #print("MeetsTerms")
                else:
                    meetsTerms = False
                    #print("!MeetsTerms")
                #print(usersNotified)
            #print("Does it meet terms: "+str(meetsTerms))      
            if meetsTerms:
                #the line met all terms
                users = sline.split("\t")[1].replace("\n", "")[2:len(sline.split("\t")[1].replace("\n", ""))-3].split("</><>")
                for user in users:
                    if user not in usersNotified:
                        #print(str(user)+" in? "+str(usersNotified))
                        usersNotified.append(user)
                        #print(str(user)+": "+rline.split("\t")[1])
                        NotifyUser(user,rline.split("\t")[1])
                        
def NotifyUser(userID,redditURL):
    #users = usersString.split("</><>")
    #print("-"*20)
    #print("User: "+str(userID)+" Link: "+redditURL.replace("\n"))
    print("sending message: "+userID)
    client.send_message(client.get_user_info(userID), content = "A trade request matching your alert has been added: "+redditURL.replace("\n",""))

#UPDATED TIMER
async def my_background_task():
    print("background task begun")
    await client.wait_until_ready()
    counter = 0
    #channel = discord.Object(id=GAME_THREAD_CHANNEL_ID)
    while not client.is_closed:
        AddMessages(messages)
        counter += 1
        print(str(messages))
        for message in messages:
            await client.send_message(await client.get_user_info(message.split("\t")[0]), content = "A trade request matching one of your alerts has been added on r/TarkovTrading:\n\n**"+message.split("\t")[1]+"**\n"+message.split("\t")[2])
        await asyncio.sleep(60) # task runs every 60 seconds
                    
# TIMER TO CHECK FOR NEW TRADE
from threading import Timer

class RepeatedTimer(object):
    def __init__(self, interval, function, *args, **kwargs):
        self._timer     = None
        self.interval   = interval
        self.function   = function
        self.args       = args
        self.kwargs     = kwargs
        self.is_running = False
        self.start()

    def _run(self):
        self.is_running = False
        self.start()
        self.function(*self.args, **self.kwargs)

    def start(self):
        if not self.is_running:
            self._timer = Timer(self.interval, self._run)
            self._timer.start()
            self.is_running = True

    def stop(self):
        self._timer.cancel()
        self.is_running = False

#rt = RepeatedTimer(5, AddMessages)

def AddMessages(messages):
    print("add messages called")
    file = open(MESSAGES_FILENAME,"r")
    print(str(messages))
    messages.clear()
    for line in file:
        messages.append(line)
    print(str(messages))
    print("Finished adding messages")
    file.close()
    file = open(MESSAGES_FILENAME,"w")
    file.close()
    return messages
    

# CALLED WHEN A MESSAGE IS SUBMITTED
@client.event
async def on_message(message):
    message.content = message.content.lower()
    if message.content.split(" ")[0] in TRIGGERS:
        #await client.send_message(await client.get_user_info("282182568101806080"), content = "Added again")
        command = re.sub(" +"," ",re.sub("[^0-9a-zA-Z ]+","",message.content)).split(" ")
        #print(str(command))
        if len(command) > 1:
            request = command[1]
            if request in ["list","ls"]:
                await client.send_message(message.channel, content = ListSubscriptions(message.author.id))
                return
            elif request in ["subscribe","sub"]:
                if len(command) > 2:
                    terms = []
                    for i, term in enumerate(command):
                        if i > 1:
                            terms.append(term)
                    terms.sort()
                    response = AddSubscription(message.author.id, terms)
                    await client.send_message(message.channel, content = response)
                else:
                    await client.send_message(message.channel, content = "You must include terms to subscribe to. Type: ```"+TRIGGER+"``` if you need instructions")
            elif request in ["unsubscribe","unsub"]:
                if len(command) > 2:
                    terms = []
                    for i, term in enumerate(command):
                        if i > 1:
                            terms.append(term)
                    terms.sort()
                    await client.send_message(message.channel, content = RemoveSubscription(message.author.id, terms))
                else:
                    await client.send_message(message.channel, content = "You must include terms to subscribe to. Type: ```"+TRIGGER+"``` if you need instructions")
            else: await client.send_message(message.channel, content = greeting)
        else:
            await client.send_message(message.channel, content = greeting)

#START BACKGROUND TASK
client.loop.create_task(my_background_task())
client.run(TOKEN)




#FORMAT FOR SENDING MESSAGE TO USER BY ID
#await client.send_message(await client.get_user_info(senderID), content = "Added again")

# FORMAT FOR SENDING MESSAGE TO CHANNEL BY MESSAGE OBJECT
# await client.send_message(message.channel, content = "You have been added to this alert!") 
